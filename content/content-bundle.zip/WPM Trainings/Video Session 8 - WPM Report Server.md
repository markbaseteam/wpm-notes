
- Report Server Project contains a service and a project where business logic is implemented
  
- ServerProxyCallback.cs contains ProxyCallBack Method. When Postmaster communicates with any server all calls will come here. Each server has this separate class so you can add a breakpoint to the server you know will be used otherwise add in all 3
  
- Important Services Include Aggregation Service and KPI Calculation Service
  
- In KPI Calculation Service GetMachineConsole() GetLineConsole() to get machine and line level data respectively
  
- CalculateKpisLive() The request for data being calculated at current level comes here
  
- GetLiveKpis() is an important method. It calls the above methods and returns all the calculated KPIs
  
- KpiCalculationService.cs includes all the members and methods for KPI calculation and all 3 servers have their own version of this class. This is because formulas are different at factory level i.e much higher level.
  
-  CalculationServiceBase.cs is responsible for calculating kpis of history section
  
- Line and Machine data are encapsulated in a single object when sending response but factory data is sent as a separate object
  
- Which Kpis are calculated and returned depends on the query by user
  
- Data aggregation is only done at hourly level and daily level. Others can be calculated using these
  
- AggregationService.cs includes methods that are called at intervals of time to aggregate data. It just calls the stored procedures which implement the actual logic
  
- Some Kpis like are not stored in factory DB after aggregation while others are saved