This is second training on Postmaster. New details mentioned below.
First lecture in detail -> [[Video Session 2 - Postmaster Responsibilities]]

- Licensing Information is being stored by OIB but it is the job of Postmaster to verify the license still holds and if it doesn't it will not show any data on frontend.
  
- Watchdog is used for performing some activity or task across all lines after regular intervals of time. The default time is 10 seconds and is configurable. For example we might ping all our servers to check their status.
  
- Web Server when forwarding a request to Postmaster mentions the type of data it requires as a response. Postmaster then decides based on data type which server should request be forwarded to. For example if we require factory level data from Factory DB then Postmaster will forward the request to Factory server for handling.
  
- When Web Server receives a request it forwards it to Postmaster which forwards it to let's say live server. Live Server will store that request and send an acknowledgement. Then it will open another channel and perform calculations then send a new response to postmaster which again forwards it to web server.
   
- While debugging this makes it difficult for us as we cannot set a breakpoint to because of this bidirectional communication. You can place a breakpoint on specific method in ServiceClient.cs and in PmCallback method in PerformanceMonitorService.cs as every postmaster call enters this method when receive request from web server.
  
- ServerProxyCallback.cs contains ProxyCallBack Method. When Postmaster communicates with any server all calls will come here. Each server has this separate class so you can add a breakpoint to the server you know will be used otherwise add in all 3.
  
- When these 3 servers communicate with Postmaster service then we can add breakpoint in subscription method in ServiceServer.cs as flow will always enter there.