
## Recipe Event

A Recipe in WPM context contains ingredients and steps to create a board like a food recipe. It will contain information like the type of board, material to be used, number of components to be placed, and time to create the board etc.

Recipe event alone is responsible for many changes in our application so we have to take special care.

**Recipe Also Includes:** 
- Board Type
- Component Information
- Conveyer Mode

As WPM developers it is not our responsibility to create recipes but we need to create recipes in testing environment.

Conveyer Mode is responsible for telling us how the board will be made i.e how work/effort will be done on the board.

### Steps WPM takes after Recipe Event

1. Store Meta Information. 
   
2. Store information in Lot, LotInConveyer, LotInConveyerArea, StationSetup 
   More details for these tables here -> [[Video Session 10 - Line and Factory DB#^fd4845]] 
   
3. Set POM. We are given cycle time at recipe download. We use this theoretical cycle time estimates to determine POM otherwise user can also choose a machine. POM is only for single conveyer machines not for dual machines.
   
4. Changeover KPI is fully dependent on recipe download event as it is triggered from when a recipe is downloaded and continues till first production event. Each Station has a separate changeover. The line level changeover is determined by POM.

****

## Board Event

Every time a board is created a board event is generated.

**Event Handler:** Receives board event

**Event Processor:** Manipulate the event data and store it in data base.

### Board Event Includes

- Board Information
	- board type
	- placed components
	- shape
	- material
	- cycle time
	 Our CWR/CWC/CRR are dependent on board event information

We use Siplace Pro desk provided by ASM for creations of any line or recipes.

