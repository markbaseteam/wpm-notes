# Line db:

## Dbo: (this is the schema name and datamodel is the table name)

**Dbo.datamodel –** product ki general info. DB ka version kya chal raha .. code ka version kya chal raha

## Factory Calender:

**FactoryCalender.ScheduleHistory** – breaks wagaira ki information

**FactoryCalender.ShiftHistory** – shifts ki information . ismain current day sy onwards 14 days ki shift bani pari hotin

## Line: (we never delete, move or archive this data, it always stays in its respective tables

## …. Yay meta data type information hy.. linehistory main production related data hota)

![](file:///C:/Users/TAIMOO~1.AHM/AppData/Local/Temp/msohtmlclip1/01/clip_image002.png)

**Line.Station** – line main kabhi bhi koi station past main lagay hongain ya lagay hoye, unki information idhr hoti ….. aoi adapter ky time line pr station kaa equipment

**Line.Setup** – jb bhi koi recipe download hoti kisi line pr, to hamain dikaana par jaata ky yay kis setup ky saath download hui thi.

**Line.Recipe** – itself recipe ki info pari hoti idhr

**Line.Line** – line ki apni info ![](file:///C:/Users/TAIMOO~1.AHM/AppData/Local/Temp/msohtmlclip1/01/clip_image004.png) 

**Line.Board** – jb bhi recipe download hoti to idhr board ki information aati ky recipe kis type ka board banaaye gi

**Line.Component** – recipe kis type ka component place karay gi iski information

**Line.ComponentShape** – component ki shape kya hogi

## LineHistory: (we never delete, move or archive this data, it always stays in its respective tables … this has information that is more related to production information)

**LineHistory.Lot** – have information about conveyer belt. … one line with multiple machines will have same common conveyer… recipe ka name, kis type ka board , setup kya hy … we link such information with this LOT … conveyer ky column main hm 1 for right, 2 for left. Agr single conveyer hy . to hamesha right aaye ga…. isPom ka aik check hy … this is point of measurement.

(why we need pom: sometime we do not need to get data of all the stations. Kisi aik sy bhi kaam ban sakta .. ya in the case when we only need to monitor one station jiska hamain pata hy ky yay waala slow kaam krta baaki theek hi hotay .. to hm usay pom main daaal daitay. )

**LineHistory.LotInConveyer** – the region of conveyer in contact with the machine. The part inside the machine ….. (machine ki characteristics)

**LineHistory.LotConveyerArea** – machine will have multiple parts that do something. 4 at max. .. at max 2 placement areas… there are 4 areas thou .. area 1 area 2, … area 4.  their information is stored in LotConveyerArea ………. (area ki characteristics)

**LineHistory.StationSetup** – this contains stationId which tells ky konsa station hy line ky saath .. conveyermode tells us ky yay alternating left and right hy, single hy , I sync hy, dual conveyer hy kya hy,..

## Log: jo simple information hm log kr rahay hotay iss schema main

MachineHistory: machine states waala data saara in schemas main aa raha hota live .. jb boards ban rahay hotay

![](file:///C:/Users/TAIMOO~1.AHM/AppData/Local/Temp/msohtmlclip1/01/clip_image005.png)

## Temp:

Jb data ko current sy move kr ky archive main ly kr jaana hota and usko aggregate krna hota .. then we use these tables.

## Archive:
When we are aggregating data we first move data to the archive tables.

## Aggregation schema. 
We aggregate production data

………………….

For aggregation, we use store procedures.

When we need data for kpi, we use store procedures like MachineHistory.GetOeeData or if we query data for multiple days, we use MachineHistory.GetDailyLineBalancingInfo.

When we need data for a day or less than a day we use MachineHistory.GetHourlyLineBalancingInfo.

For current view, we use GetLineBalancingInfo.

Purging ky liyay bhi store procedures hain.

# FactoryDatabase:

## Settings:

**Settings.systemSettings** – settings that are applied immediately

**Settings.FactoryParameterServerSettings** – these  settings are applied at shift end.

## Factory:

**Factory.ProductionLine** – tells us about the total number of lines in a factory. And wo kb create huin. Those that are enabled, we put their database server id to 1, else we have null there.

**Factory.ProductionLineHistory** – aik line kb disable hui, and kb tk wo disabled rahi. Lines that are currently disabled have null in their end time.

**Factory.Alert** followed by something waalay tables keeps track of of Alert Subscription Setting.

![](file:///C:/Users/TAIMOO~1.AHM/AppData/Local/Temp/msohtmlclip1/01/clip_image007.png)

## Aggregation:

Some kpi data we are aggregating at the shift end and we are storing in the aggregation tables.

![](file:///C:/Users/TAIMOO~1.AHM/AppData/Local/Temp/msohtmlclip1/01/clip_image009.png)

We also have store procedure for these aggregations.

## Aggregation.FactoryShiftView

Most important view. Factory level pr history main jaa kr shift ka filter comes from this view.