
![[Pasted image 20230815104252.png]]

**Postmaster:** All the communication between frontend and backend is facilitated by Postmaster. Frontend doesn't know which WCF module should the request be forwarded to. Postmaster redirects to appropriate server and when the server returns data postmaster sends response to UI. Bidirectional Communication. Even the login call to OIB is done by Postmaster.

OIB Contains factory level configuration information and user accounts information which it passes to postmaster for further redirection to servers ahead. Licensing Records are maintained by OIB. Revoking access is also done by Postmaster.

**Live Server:** All live/Realtime data processing and inserting in database. data proportional to factory machine count.

**Report Server:** All line level data for kpis in a certain time period. Fetch data from dbms perform kpi calculations and then send to frontend.

**Factory Server:** All Factory level data for kpis in a certain time period. Fetch data from dbms perform kpi calculations and then send to frontend.

(All above are WCF architecture servers except Postmaster)

## Responsibilities of Post Master

*****
### Factory Layout Retrieval from OIB

All lines Information from OIB and related services is retrieved by Postmaster service.
### Health Check

WPM Service Reports and Health Reports are shown on frontend and notifications and warnings are also sent to OIB which is also responsibility of Postmaster.
### Licensing and Auth

All license management and revoking access is done through Post Master. The login call to OIB is through Postmaster.
### System Settings

General settings for factory level like Logo, Week and timings Configuration, Interval, Login, Line enable/disable, subscriptions. These have small business impacts.

Updating System settings in Db is responsibility of Postmaster.
### Parameter Settings 

These are responsibility of Live Server. Will discuss in detail in [[live server lecture]]

**Important:** WPM is an external performance monitoring tool. Client is responsible for data collection and then by sharing IP Address of OIB with WPM we connect them. One WPM against a single OIB. But WPM can have multiple clients.
### Watchdog

Any activity or task for all lines after regular intervals of time is done through watchdog which is part of Postmaster service. Default value is 10s. Like Pinging Servers to check their status after every 10s.

### Scenario: Load Balancing by Postmaster

The recommended lines is 8 per factory by WPM. Lets say we have increasing number of lines so load on live and report server will increase. We can handle the scaling by creating a new child server instance with new instances of these two. Lines 1-8 will go to Parent Server. Others will go to Child Server. This load balancing is also done by Postmaster which knows how many servers are working at the given time.

*****
## Diving into Postman Service Codebase

### Cache: InformationCache

Postmaster has an In-Memory cache which holds frequently accessed data from dbms. If a change is made to data from frontend we need to make sure the dbms changes are synced with cache data. Cache is also responsible for storing external data like if we are getting a lot of data from OIB.

If Postmaster is down due to anything all this lost. We have to store some state before this service crash. We now store all this cache information in a table so after the service is restarted we can return to the state before crash in 1-3 minutes.

**Important:** All the information in Postmaster Cache is in class **InformationCache**

### UserManagement

This class is responsible for user account information and related methods. Our Communication with OIB like subscribing and unsubscribing is being handled through this class. Roles are also managed through this class.

### ConfigManagerHandler

Responsible for factory level information and methods. Like GetAllLines() which is part of FactoryLayoutService.

### HealthCenterService

Health Center shows health of service and we show it on screen as notifications and also share the status to OIB.

## Communication between Postmaster and OIB

![[Pasted image 20230815114909.png]]


### Communication with other servers

![[Pasted image 20230815115014.png]]

We can see in this example of central settings(This is outdated now) that Postmaster fetches them and then redirects to live server as middle service between OIB and Live server. This way we have a single path of communication instead of All 3 servers fetching data themselves.

### Storing data to databases from servers

![[Pasted image 20230815115339.png]]

### User auth via Postmaster

![[Pasted image 20230815115458.png]]

## Retrieval of Data from Centralized Database via Postmaster

![[Pasted image 20230815115539.png]]

Postmaster decides which of its client will perform the job. Here it is using factory server since we need to get data from factoryDB. Factory Server decides via internal implementation to get data either from FactoryDB, in-memory data or some other internal calculation is to be performed.
### Extra Information 

We have two types of WCF Services 
- One way: Client-Server where Server only sends messages to client(One-Way)
- Duplex: Two way communication where messages can be sent in any direction. Consider two services A and B. When A sends message it acts like server and B as client and vice versa.

Lets say we receive a request on web server. This will be further passed to postmaster which may pass it to a service like Like Server. The Live Server will then store this request in a queue like maybe hold it in cache while sending an Acknowledgment. Live Server will then prepare a response and send it to postmaster which again sends it to web which validates if the response is what was required and then display an error or results. 

Usually History and Settings are the only request based data. Other data like for current is being pushed by backend itself.


