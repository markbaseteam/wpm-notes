
## Production Line

A production line in our context is one or more machines working together to place components and produce a complete board.

![[Pasted image 20230811171805.png]]

## Data from SMT Machine

![[Pasted image 20230811171837.png]]

## OIB

Software of ASM that shares all this data. We have to subscribe to it to receive all this data. Learn More  -> [[Video Session 4 - ASM OIB]]
## AOI
![[Pasted image 20230811172503.png]]

## Machine State Mapping into E10

![[Pasted image 20230811171916.png]]

## E10 States

![[Pasted image 20230811171944.png]]
 - Productive means actually working
 - Standby means idle state
 - Unscheduled Downtime refers to error situations
 - Engineering is when New recipe is being downloaded and tested. It has a flag which can be turned on to show all the current boards are under testing
 - Scheduled downtime includes small breaks like factory breaks or holidays. These are mentioned on factory calendar
 - Longer breaks are included under non scheduled time like 3 days due to power outage or month long factory break
## KPI's Dependent On Machine State
### Utilization 

How good a machine is performing with respect to productive time. We are only measuring the time the machine is in productivity. The denominator is configurable.

- For example in an hour data set the machine is running for 30 mins and is idle for 30 mins so formula can be:

**Utilization = Productive / (Productive + Standby)**
= 30/60 = 50%

### Availability

How good a machine is performing with respect to one or more state(Productive+Standby). The main difference from utilization is that it is not only concerned with productivity but also the time machine is available. Both Numerator and Denominator is Configurable in this. 

- For example in an hour data set the machine is running for 20 mins and is idle for 20 mins and in error state for 20 mins so formula can be:

**Availability = (Productive  + Standby) / (Productive + Standby + Unscheduled Downtime)**
= 40/60 = 67%

### Changeover 

This is also a state based KPI but this is a Sub kpi.

![[Pasted image 20230815131350.png]]

**IMPORTANT**

All KPIs are on 3 levels(Machine, line, factory) but their sources are E10 State.
No State for line or factory only machine has state.

## POM (Point of Measurement)

For some Kpis(Only State Dependent KPIs) we may choose a single pom for entire line like utilization of a single machine to show it at line level. (The ASM team knows how to choose the appropriate machine for this purpose)

## KPI's Dependent On Boards/Components

![[Pasted image 20230811170907.png]]

**Sources For LBI**
- Recipe
- Planned Cycle Time
- Actual Cycle Time

![[Pasted image 20230817104750.png]]
### Component Cost Rate

Does the same thing as Component waste rate but tells the wastage in terms of cost to the client.
### Component Reject Rate 

This is a subset of Component Waste Rate. Component Waste Rate is not concerned with Error Types( Rejected, Drop, Pickup) whereas this is only concerned with reject error state.

**CRR = Rejected / Total                      CWR = All Errors / Total**

![[Pasted image 20230817105754.png]]



## KPI's Dependent on Machine State and Board/Component Data

![[Pasted image 20230811171118.png]]
Only productive time needs to be considered

![[Pasted image 20230811171404.png]]


## KPI's Dependent On Inspection Data

These are also the ones that will be sent by Classification Process or by AOI Machine

### Quality

![[Pasted image 20230811171603.png]]

### Yield

Yield is a Sub-KPI that shows the percentage of products that pass the inspection and meet the specified quality standard. A higher Yield value means a lower percentage of defective products, and thus less repairs and a higher quality of the finished product. You can use Yield to evaluate the production quality and deduce the amount of rework required. Yield data can be received directly from the AOI machine.

Yield comprises of **First Pass Yield** and **Final Yield**. For **First Pass Yield**, the yield values are coming from the AOI machine, while the yield values coming from the classification area are summarized as **Final Yield**.

Yield has different calculations based on board/component and factory/line levels. See below:
[WORKS Performance Monitor Help - Yield](http://172.18.50.29/ASMPT.AS.WORKSPerformanceMonitor/API/Client/help/WPM%20Online%20Help.htm#APM/SubKPI/Yield.htm?TocPath=Sub-KPI%257C_____5)

![[Pasted image 20230811173333.png]]
can select only one at a time and that will define the workflow. SubKpis can be selected as required. Yield is must for OEE.

- With OEE (SEMI) you can evaluate the operation efficiency and appraise how optimized the operation process is.
  
- With OEE (Benchmark) you can evaluate how suitable the product is to the current line configuration. The better the product fits to the line configuration, the closer it gets to the line's capability.

**It is possible to choose both definitions at the same time. In this case, the KPI gauges for OEE (SEMI) and OEE (Benchmark) will appear next to each other in the KPI Section.** 
### OEE
Overall Equipment Efficiency 
Product of 3 different KPIs 

