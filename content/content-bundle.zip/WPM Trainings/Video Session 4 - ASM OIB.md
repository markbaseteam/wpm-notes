
### OIB - Operations Information Broker

![[Pasted image 20230815171216.png]]

#### MSMQ

MSMQ is a messaging protocol that allows applications running on separate servers/processes to communicate in a failsafe manner. A queue is a temporary storage location from which messages can be sent and received reliably, as and when conditions permit. This enables communication across networks and between computers, running Windows, which may not always be connected.

#### Spooling

Spooling is a process in which data is temporarily held to be used and executed by a device, program or the system. Data is sent to and stored in memory or other volatile storage until the program or computer requests it for execution. 

![[Pasted image 20230815171716.png]]

## User Manager

![[Pasted image 20230815172709.png]]

## Subscription Administrator

![[Pasted image 20230815180923.png]]

## Factory Calendar

![[Pasted image 20230815181018.png]]

- ASM Studio allows Shifts only at Enterprise level
- We are allowed to make Scheduled Downtimes at Line Level
- Our ASM and OIB need to be in Same Time Zones to perform factory calendar operations
- If we make a Scheduled/Non-Scheduled downtime and then later make any change in it. That downtime will be stopped and a new one created will start from the same time. 
- Shift always need a start time in future but this is not required to create downtimes.
- Downtimes can be in a shift or even cross-shift.

## Health Manager

![[Pasted image 20230815183559.png]]

### UI View

![[Pasted image 20230815183808.png]]

## Factory Explorer

![[Pasted image 20230815184256.png]]



