
Board data to get information regarding machine. In source-code it referred as board events 

### Board Events 

When board exits from a machine conveyer a board event is generated. 

It contains info regarding: 
- Machine 
- Material 
- Time taken to produce 

In source code validations are first place at board (line) then data is dumped into queues in WPM, from there some data in stored in data table (if further processing is required on data) or insert in database directly through stored procedures. Some data is passed to line overview for the specific live data in real-time.

**Cycle Time/Build Time:** The time taken by machine to produce board. 

****
## KPIs

[[Video Session 0 - What is WPM]] -> KPIs Covered in detail from video lectures
### State Machine KPIs

#### Utilization 

How much through put machines are giving (Different formula than OEE, not run together), how much time machine is productive. 

#### OEE (SEMI, Benchmark, LU) 

How much through machines are giving (Different formula than Utilization, not run together), how much time machine is productive. 

Benchmark: Its mixture of machines and board data. 

SEMI:  Its time-based calculation to calculate machine productivity 

LU (line utilization): Calculated based on hardcode formula

#### Changeover 

Time taken by you to change machine layout to produce some other thing, the time taken in this activity is known as changeover time. Calculated based on events. 

How soon your machine can be ready for next production.  Commonly used when recipe is changed.

### Board Base KPI 

#### LBI (Line balancing indicator) 

A machine can have two placement area (pa1, pa2).  We show build time, to show build time average that if board is producing in given time. In case a build event from a machine contain two PA1 and PA2 we treat them two separate instances of machines. 

We take build time data from stored procedure then get max min and avg. 

In case of lines we get the show of machine, in station we show machine time.  

#### CWC/CWR/CRR (Component waste cost/component reject rate) 

CWC: How many components are wasted during board production shown in the form of how much it cost. 

CWR: (component waste rate): it is show in % same as CWC. 

CRR: high probability that it can re-used again. 

#### Yield 

How much board conforms to the quality standard checked at the end line 

DEK(Printer)-AOI (Quality assurance)-SMT (Surface mount technologies)

