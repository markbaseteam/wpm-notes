
We have a single factory db against all factory data and it is created during the installation process. Default Name is APMFactoryDB but configurable.

We have multiple line Dbs against each enabled line and it is created when a line is enabled. Naming Scheme is as follows:
**FactoryDBName_UniqueLineId_LineOibPath**
### Important Tables of Line DB

#### DataModel 

![[Pasted image 20230817151052.png]]

**We know from schema name what kind of data is being stored in the table. For example in FactoryCalender.ShiftHistory factory calender is schema and shift history is table. We know from schema that table will contain data related to factory calender**

Line Schema is special in a sense we don't aggregate, delete, move or archive any data from tables of this schema. For example in Line.Station we have data related to stations on a line and even if you later end up removing a station you still won't delete its data from this table. Information in line schema is more of metadata type.

LineHistory includes information more towards production, like the information during production that you don't want to aggregate, delete, move or archive is part of this schema. The lot, lotInConveyer and LotConveyerArea are part of this schema. ^fd4845

![[Pasted image 20230817154110.png]]

- **Lot Table:** As Recipe remains same across stations on a conveyer so some data is common to all stations on a conveyer. The information is called conveyer level information and is stored in Lot table.
  ![[Pasted image 20230817152628.png]]
  
-  **LotInConveyer Table:** The Region of conveyer enclosed by a machine is called Lot in Conveyer. This table encloses the conveyer(Lot) data in context of this station. It stores the characteristics related to station like we find the flag if the station is POM or not in this table.
  
- **LotInConveyerArea Table:** This deals with the concept of placement areas(Heads where components are placed). There can be maximum of two placement areas in a station. If we are uniquely identifying this placement areas we will call it LotInConveyerArea. Similar to concept of POM we store data of both area but only show data of slower area(Determined by Bottleneck flag) to user. That is why we call this area bottleneck area.
  
- **StationSetup:** We have a join to this table from LotInConveyer table and this table contains important information like Conveyer Mode. Conveyer mode can impact data calculation. 
#### Log schema

tables with log schema are used to log information
#### Machine Factory Schema

tables with machine factory schema are used to store current level production information like changeover times, machine states, aoi board history, board cycle times and board consumption history.
#### Temp Schema

Tables with temp schema are used at the time of archival and aggregation.
#### Archive Schema

When we perform aggregation we migrate data to archive. The tables are same as machine factory schema tables. So if there is any issue we can cross check the data from archive tables till 14 days.
#### Aggregation Schema

Production data after aggregation goes into these tables. We have a prefix of hourly or daily to show which type of aggregated data it is.

**Note:** To get information for calculating Kpis, purging or aggregation of data we have created stored procedures which we call as required.

****
### Important tables of Factory DB

#### Settings Schema

Includes a table for Settings.SystemSettings which are settings applied instantly. Also includes Settings.FactoryServerParameter for parameter settings which are settings applied at next shift.
#### Production Line

Contains the data regarding how many lines in factory. The lines which are not enabled have null in DatabaseServerId column otherwise there is a valid id.
#### Factory Production Line History

Contains Information like the time when line was disabled(Start time). Also contains end time or null if it is still disabled.
#### Alert Tables

Contains data for alerts and subscriptions features
#### Shift History 

Not Used Much as We also contain all shift information in separate line Dbs.
#### Aggregated KPI tables

Some Kpis are aggregated and stored in factory db like yield, changeover and Line balancing indicator. 