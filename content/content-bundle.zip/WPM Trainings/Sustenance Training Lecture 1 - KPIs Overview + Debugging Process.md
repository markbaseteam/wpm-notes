#### Debug

In sustenance we deal with bugs reported by customer. Error Report is attached with the bug which contains log files, UI Screenshots and Database Backups.

We have to generally analyse most of the information ourselves using log files. Filter log files by date and time of error and check in Yats. 

For Service related errors go through EventLog Files. 

### Changeover KPI

There are two types of change overs:

- table change over 
- setup change over
 
when order number is changed, APM considers it a table change over and this has less alert and target time set for changeover. This is because recipe is same, just order is different. 

when a serious change over is required, ie- line configuration physically change honi,kuch equipment add hona ya kuch aaisa - this is represented through setup change over 

changeover will have a target time and alert time, time before target time is reached will be added to on time, and time beyond target time is added to lost time.
on time is counted in scheduled downtime 
lost time is counted in unscheduled downtime

**Live server** has two steps:
	**pre engine**- responsible for handling events from SPI(maybe it was oib dont remember)
	**post engine** - responsible for storing data that arrived through the events in the respective database.

**Report server**- calculates line and machine data for kpi and its aggreation. 

**Factory server** - auto report generation, history for factory console, data purging, manage kpi targets and alerts
### OIB 

Line server AKA LinePC 
Stations ( AKA SEREO software )

recipe is against a board, each board consist of multiple components.

board events consist of board related information.

Rejected, material defect, other type of rejects. dropped, etc. 

consumed components (lets say 100) vs placed components (lets say 98)   -  98 percent yield

****

### Yield 

Yield is calculated through 
- Aoi adapter or 
- equipment connecter or
- manual entry

yield is of two types:
	component based and board based --- quality information comes from here

for OEE calculation:
	availability, quality, performance are needed




