dailyboardinfosummary : board information

merge kin machines main hota 
plausability waala kya table hy


reportdistibution waalay table main hm iss cheez ki data rakhtay ky ab tk ka data bhaij diya hua ya nai .. this is different from.

14 days ki shift kuin banaatay


triggering criteria: line db sy shift end pr sp chalta .aur factory db pr store hota.


14 days ki jo shift banaatay hain .. wo advance main shift banaanay ky liyay hhy naa ...  jaisay kl ki shift bana li.

liveserver main monhandler hy monitoring event ka handler.  

state data stationavailability 

recipe download event handler
onboardprocessedevent
re


report server main hamaaray pass hoti aggregation service ki calss


ssis package execute

rdlc reports factory ki reports waalay server main hoti

kpicalculationservice and calculationservicebase mainly data collect

current ka saara data line level sy aata ..even factory ka current 

pmcallback