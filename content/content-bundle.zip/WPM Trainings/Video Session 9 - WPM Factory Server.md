
### Responsibilities of Factory Server

- Calculating KPIs for factory console either for current view or history view
- Another important responsibility is data purging
- Auto Report Generations
- KPI Target and Alerts

**Important:** We set Push KPI Interval and after that interval we get data for factory console from factory server. The Line cards are also being calculated by the factory server.

When client makes a query by adding filters in factory screen post master forwards the request to factory server.

Factory Server also has its own KpiCalculationService.cs and CalculationServiceBase.cs responsible for calculating KPIs for current and history view
### Data Purging

ASM Licenses are of 24 Months and then its responsibility of Factory Server to delete the aggregated historical data of 24 months. We have written a service that runs every 12 hours to check and run Stored Procedures for data purging whose job it is to delete older data.

### Auto Report Generation

As a shift or day ends, then WPM will automatically generate a report for the shift or day and either share it in a shared location or email to stakeholders, You have to subscribe to receive these reports. This calculation of reports based on meeting certain criteria is responsibility of Factory Server.

### Target and Alert

We can setup target and alert subscriptions like sending alert emails to appropriate person and this is also the responsibility of factory server. You can find implementation in AlertTriggeringService.cs

****

### Integration Service Catalogs

Sql has Integration service catalogs which using packages migrate data from one database to another. For example we migrate our line level data to factory level db. This migration is done through SSIS packages. This makes a catalog which is made from installer end. 

We have two packages
- Master Package responsible for creating package connections against enabled lines
- Child package which is responsible for taking further backup and moving data. Child package has stored procedures responsible for migration. Look into ExecuteSsisPackage() method and it also useful as a breakpoint.


**How do we know how much data has been migrated?**

We have isAggregated flag in many Dbs which tells us till where our aggregation has been done and we keep the time till which we have migrated.





