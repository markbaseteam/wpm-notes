
Conveyer means a single line belt which may have one or more machines that it passes through. Like the conveyer belts in a factory.

## Conveyer Modes

- **Single:** A single line belt
- **Double:** Two line belts going adjacent to each other. Would have machines stations on both lines whose working will depend on configuration

#### Dual Machine

If we join two single machines we will get a dual machine
#### Placement Areas

Where the actual placing of components is done with a head. There can at most 2 placement areas per machine.

## Placement Modes

#### Dual Asynchronous

Consider 2 boards on 2 conveyer lines enter a machine. In this mode there will be no concurrent work on boards. First both heads will work on a single board and after finishing work on the other one. We save time in sense that we don't have to wait for any board and waste time. To calculate time consider two boards enter and each takes 10s to complete therefore the total time taken will be 20s. Since in any case we are waiting for both to complete so we can take the time of right conveyer belt always. This is inline with merging method.

#### I-Mode / I-Placement

Concurrent work on both boards by separate heads. Consider both boards take 10s to complete so the total time taken will also be 10s as we will take average time as parallel work is being done. Here if a board is completed it will not wait for the other to be completed and be moved along the conveyer line.

#### Dual Synchronous

This mode works similar to I-Mode but the difference lies that the board that finishes first will wait for the other board to complete before moving forward. We can say they will be in sync.

#### Alternating left and right

We only utilize half of the dual machine formed. Either only left machine will do all the work or either the right machine will do all the work.

#### Special Case: 

Consider there is a board on both conveyers but right now both heads are working on a single board. The Machine where work is being done is considered to be in productive state and the machine that is sitting idly is said to be in standby mode.


## Method to Calculate Time

We use merging method to calculate time. In merging method we consider the precedence of the state. For Example:
- Productive State will have higher precedence than Standby Mode
- Error State will have higher precedence than Standby Mode

****

## Current and History Tabs in WPM UI

Current data shows the data of the current shift. It is represented by a line trend graph as is common for continuous display of data. 

**Shift:** A shift is a time period like a morning shift or a night shift 

**Cross Hour:** Cross hour refers to the fact when the time period for an activity goes past an hour. This concept is important as WPM deals with time in the form of hours like a clock.

**Hourly Cut:** Hourly cut is used to handle the concept of Cross hour. We have 3 columns

	**Start Time | State | End time **

Start time and state are entered and end time is null at the beginning 
Once we transition to another state the end time of previous is added as the start time of current.

Consider a job starts at 8 and ends at 9:10 then there is a second that starts from 9:10 to 10. To represent it on trends graph we will have a bar graph from 8-9 showing(centred at 8) that shows the boards made during that time. Then there will be a bar graph from 9-10(centred at 9) that shows the boards made during 9-9:10 and 9:10-10:00. The details can be shown by tooltips. 

The line boxes show the time being actual time being represented like a bar on 8 actually means from 8 to 9 which will be represented visually by a dashed line.
