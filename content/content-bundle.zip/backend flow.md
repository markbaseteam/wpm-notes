

# live server 


## program.cs

 private static void Main(string[] args)
        {
            var service = new LiveServerService(new ApplicationService());
            if (Environment.UserInteractive)
            {
                service.RunAsConsole(args);
            }
            else
            {
                ServiceBase[] servicesToRun = {service};

                ServiceBase.Run(servicesToRun);
            }
        }
here we are creating an instance of the live server service and 
if the environment is userinteractive ie. console ya cmd, to it runs the service there,
else it runs it as a service.

[ExcludeFromCodeCoverage] indicated that this code should be excluded from code coverage analysis. Code coverage analysis is a technique used to determine how much of your codebase is covered by automated tests 


## liveserverservice.cs

namespace Asm.As.PerformanceMonitor.LiveServer.Service
{
    public partial class LiveServerService : ApmServiceBase
    {
        public LiveServerService(IApplicationService applicationService) : base(applicationService)
        {
            InitializeComponent();
            DoNotCheckForLicenses();
        }
    }
}

`public partial class LiveServerService : ApmServiceBase`:

- This line defines a new class named `LiveServerService` that is marked as `partial`. The class inherits from another class called `ApmServiceBase`. 
- In C#, a `partial` class can be split across multiple source files, and all parts of the class are combined at compile-time into a single class.
- the constructor of the class is calling the constructor of the base class and passing it applicationService as parameter


 public void RunAsConsole(string[] args)
	{
		OnStart(args);
		Console.WriteLine("Press any key to exit...");
		Console.ReadLine();
		OnStop();
	}

run as console is called when the code is run in interaction mode.
it uses the OnStart Method of the ApmServiceBase class


## apmservicebase

 protected override void OnStart(string[] args)
{
	ApmHelper.ConfigureAndWatch(new FileInfo(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile));

	WaitUntilOtherAdapterInstancesAreStopped(5 * 60);

	_applicationService.Initialize();
}

the ApmHelper.configureAndWatch will take the path of a configuration file. and use it before calling the applicationService.Initialize()


## ApmHelper:
public static void ConfigureAndWatch(FileInfo fileInfo)
        {
            if (fileInfo == null) return;
            XmlConfigurator.ConfigureAndWatch(fileInfo);
        }

this function will watch the configuration file for any changes and reloads the configuration for any changes


## applicationServiceBase
public void Initialize()
        {
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            ResolveDependencies();

            _serverProxyCallback = Initialize(ServiceServer, ProxyCache, TaskService, DatabaseService);

            _initialThread = TaskService.CreateThread(() =>
            {
                using (new RuntimeContextScope(RuntimeContextType.Common))
                {
                    var version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
                    Log.InfoFormat("Initialize started for {0} - Version: {1}", Server, version);
                    // Try to start Observation service
                    try
                    {
                        //get observation wcf service address from App.config
                        //keys are :
                        // [Observation.Receiver.Tcp.Address]
                        // [Observation.Receiver.Port]
                        Uri observerAddress = ObserverEndPointProvider.Instance.GetObserverTCPUri();
                        _obsReceiver = new ObservationReceiver(ObserverSelector);
                        _viewerServiceHost = new ServiceHost(_obsReceiver, observerAddress);
                        _viewerServiceHost.Open();
                        Log.InfoFormat("ObserverReciever is launched on address ---> {0}", observerAddress);
                    }
                    catch (Exception e)
                    {
                        Log.Error("Error while starting observation service ", e);
                    }

                    try
                    {
                        Thread.Sleep(TimeSpan.FromSeconds(2));

                        if (ServiceServer.Start(_serverProxyCallback.ProxyCallback))
                            Log.Info($"{Server} connected to Post Master successfully");
                        else
                            Log.Warn("Failed to connect to Post Master");
                    }
                    catch (Exception ex)
                    {
                        Log.Error($"Initialize({Server}) got exception", ex);
                    }
                    finally
                    {
                        Log.InfoFormat("Initialize finished for {0}", Server);
                    }
                }
            }, $"Start{Server}");
        }
* this first calls currentdomain.unhandledexception, to handle any such exception
*  _serverProxyCallback = Initialize(ServiceServer, ProxyCache, TaskService, DatabaseService);  -  this sets up the proxy callback for the postmaster.
* this proxyCallback waala initialize is defined in the liveServer.preEngine. here all the neccessary connections are established.






