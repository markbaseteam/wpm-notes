
frontend calls getFactoryConsole method  in the liveAnalysisController.cs
factoryKpi newModel = _ liveService.GetFactoryKpi(); 
the getFactoryKpi is implemented in the liveDataService.cs;
it returns _factoryKpi which if you will see is already filled with data which must have been filled at a different time (need to find when it is first filled and updated)
![[Pasted image 20230904175640.png]]




![[Pasted image 20230904175813.png]]


the value is returned and factoryconsoleviewmodel result is set with those values and returned to frontend.



# now backtracking _ factoryKpi:

private readonly FactoryKpi _ factoryKpi = new FactoryKpi();

i believe that factoryKpi is being filled with values whenever this function is called.
## 
private void OnFactoryLiveDataReceived(FactoryKpi response, DateTimeOffset calculatedTime)
        {
            try
            {
                lock (_factoryKpi)
                {
                    //To resolve the issue #2680 , remove cards from UI when  lines are disabled
                    if (response == null)
                    {
                        _factoryKpi.LineCards?.Clear();
                        _factoryKpi.Utilization = new FactoryUtilization();
                        _factoryKpi.ChangeoverTime = new FactoryChangeoverTime();
                        _factoryKpi.ComponentWaste = new FactoryComponentWaste();
                        _factoryKpi.LineBalancingIndicator = new FactoryLineBalancing();
                        _factoryKpi.Oee = new FactoryOee();
                        _factoryKpi.Yield = new FactoryYield();
                        _log.Debug("All Monitoring Lines are disabled");
                        FactoryKpiUpdates?.Invoke(calculatedTime, null);
                        return;
                    }
        }
**the function is larger that this, i just deleted the rest of it**


OnFactoryLiveDataReceived is called when the constructor for the LiveDataService class is called.

now, the liveDataService is called 3 times, two are in a smoke test, and once in **Global.asax.cs**

in the start() method.

the start method is called once in the Application_Start() of Global.asax.cs


monhandler ko explore kr raha 
repair states kya lg rahin.. and yay wo
line controller









# system settings ky update ka flow

in systemSetting controller ---> saveSystemSettings
systemSetting service ---> SaveSystemSetting
performanceMonitor Service ---> SaveSystemSetting
systemSettingHandler  ---> SetSystemSettings


here it makes a request object and queries that request object

 
 ````
 
 APMSystemSettingRequest request = new APMSystemSettingSetRequest
                {
                    Data = list.Select(a => new ApmSystemSettings
                    {
                        DataSource = a.DataSource,
							......
                    }).ToList()
                };
                if (_serviceClient != null) response = await Query<bool>(request);

````

systemSettingHandler  ---> query

````

case nameof(APMSystemSettingSetRequest):
                        result = _serviceClient.AddOrUpdate(DataTypeConstants.APMSysSettings, ApmHelper.SerializeToBytes(dataRequest));
                        break;

serviceClient.ClientProxy ---> AddOrUpdate
postmaster .serviceClient ---> addorupdate
now backtracking _ factoryKpi:


````




# Utilization From Factory Db
## CommonTool
### ApmServiceBase.cs
Start() --> OnStart()
## DataReciver
### ApplicationServiceBase.cs
Initialize() 

## factory Server Business Server
### serverProxyCallback.cs
1. ProxyCallback --> GetLiveData()    --- [we going with this]
2. PushFactoryLiveData --> GetLiveData()
3. DataEventPushTimer --> GetLiveData() --- [this is also reffered in ProxyCallback]
4. subscribeForLiveData --> GetLiveData() 
GetLiveData()

### KpiCalculationService.cs 

1. GetFactoryLiveKpis() --> GetFactoryConsoleLiveKpiEx() 
2. GetHistoricalData() --> GetFactoryHistoryKpisEx()


### factoryUtilizationInfo.cs

GetFactoryConsoleKpi() --> GetInternalUtilization() --> GetUtilizationFromFactoryDb() --> CreateInternalUtilization()






#

stateServiceBase.cs
stateMachines.cs
machineStateKpi.cs
processNewState()

..............................

........................





machine state handler

machinestaterepair


live data call in shiftfinish


also explore 
LiveServer.PreEngine main MonHandler.cs main Connect()

#


# monhandler waalaa flow : 

## CommonTool
### ApmServiceBase.cs
### OnStart()

## DataReciever
### ApplicationServiceBase.cs
Initialize()


## LiveServer.PreEngine 

### ServerProxyCallback.cs
ProxyCallback()

### MonitoringService.cs
DoMonitorLines() --> StartMonitoring()


### LineController.cs
InitLineSubscriptions() --> CreateLineSubscriptions()

### MonHandler.cs
InitializeSubscriber() --> SubscribeToEvents()
![[Pasted image 20230905183825.png]]
here we get the instance of the _ oibMonSubscriptionManager which subscribes to the recipedownload event and we pass it the event handler.
whenever recipeDownloadEvent occurs, we call the OnRecipeDownloadEventHandler










# repair state waala flow :

## Event queue
### msmqMessageChannel.cs
MainMsmqOnPeekCompleted()
OnPeekCompletedBase()
### MessageProcessor.cs
ProcessMessage()
## post engine live server
### factoryCalenderEventProcessor.cs
process()
## businessLogicLiveServer 
### statemachine.cs
processMachineState()
### stateservicebase.cs 
processNewState()


# #DoRework  







# monDal means  monitoring data access layer
this is a convention




DAL 
repository model





# reporting server kpiCalulation service flow

windowsServiceHelper --> start()--> onstart()

## dataRetriever
### ApplicationServiceBase.cs
Initialize()
## reportServer.businessServer

### ServerProxyCallback.cs
ProxyCallback()


1.  OnAPMSysSettings() -> UpdateKPIPushInterval()
2.  OnMonitorLines() -> UpdateKPIPushInterval()



### ReportingService.cs
UpdateKPIPushInterval()
PushLiveData()
SendLiveData()  in this function we first go to path 1 to calculate the kpi and then we go to path 2 to send data back to frontend


`path1 `{
### kpiCalculationService.cs
GetLineLiveKpis()  
GetLineConsoleLiveKpisEx()

## dataRetriever
### ComponentWasteInfo.cs
GetLineConsoleKpi()
}

`path2` {
## dataRetriever
### PushService.cs
PushKpi()
PushToClient()

## ServerProxy
### ServiceServer.cs
Publish()
### postmasterHandler.cs
Publish()

## Postmaster 
### ServiceServer.cs
Publish()

}

