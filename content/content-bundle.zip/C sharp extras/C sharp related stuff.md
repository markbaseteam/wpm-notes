
*Sealed classes* - are used to restrict the users from inheriting the class. A class can be sealed by using the sealed keyword

*Partial classes* - It is possible to split the definition of a [class](https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/class), a [struct](https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/struct), an [interface](https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/interface) or a method over two or more source files.

[SerializableAttribute] 
partial class Moon { }
here the syntax we are following is using attributes to further define class Moon, SerializableAttribute is an attribute here.
It provides metadata to the C# compiler and possibly other tools about the nature of the `Moon` class.

`out bool isCurrentShift`: This is an `out` parameter, which means that the method can modify the value of this parameter and the modified value will be available after the method call. It's of type `bool` and will be used to return some boolean value from the method